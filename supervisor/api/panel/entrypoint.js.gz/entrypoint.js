
try {
  new Function("import('/api/hassio/app/frontend_latest/entrypoint.2471a57c.js')")();
} catch (err) {
  var el = document.createElement('script');
  el.src = '/api/hassio/app/frontend_es5/entrypoint.43c7c12c.js';
  document.body.appendChild(el);
}
  