
try {
  new Function("import('/api/hassio/app/frontend_latest/entrypoint.c64d3ee6.js')")();
} catch (err) {
  var el = document.createElement('script');
  el.src = '/api/hassio/app/frontend_es5/entrypoint.4a2722b2.js';
  document.body.appendChild(el);
}
  